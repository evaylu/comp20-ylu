// app.js -- http://mysterious-reef-8155.herokuapp.com/

var express = require("express");
var app = express();

app.use(express.bodyParser());

//app.set('title', '2048 Game Center');	how does this work?

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

// POST /submit.json API
app.post('/submit.json', function(request, response) {
	// enable Cross-origun resource sharing
	// reference: http://stackoverflow.com/questions/11181546/node-js-express-cross-domain-scripting
	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	// Question: how do you get username from the POST request?
	// Answer: request.body.NAME_OF_FIELD_HERE
	username = request.body.username;
	score = request.body.score;
	grid = request.body.grid;
	console.log("username: "+username + "; score: "+score+"; grid: "+grid);		
	// testing: curl --data "username=ylu&score=1000&grid=something" http://mysterious-reef-8155.herokuapp.com/submit.json

	// check if all three data are submitted
	if (username != undefined && score != undefined && grid != undefined) {
		console.log("inserting data...");
		theDocument = {
				username: 	username,
				score: 		parseInt(score),
				grid: 		grid,
				created_at: new Date()
		};
		// enter data into Mongo -- mongodb://localhost/scorecenter/score
		db.collection('scores', function(error, collection) {
			collection.insert(theDocument, function(err, sved) {
				response.send(200);
			});
		});
	}
});


// - Home, the root
app.get('/', function(request, response){
  	// enable Cross-origun resource sharing
  	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");


	db.collection('scores', function(error, collection) {
		collection.find().sort({score: -1}).toArray(function(error, cursor) {
			if (!error) {
				var html = "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
				for (var count = 0; count < cursor.length; count++) {
					html += "<tr><td>&nbsp;&nbsp;&nbsp;"+cursor[count].username+"&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;"+cursor[count].score+"&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;"+cursor[count].created_at+"</td></tr>";
				}
				html += "</table></body></html>";
				// or use Jade
				response.send(html);
			}
		});
	});
});


// GET /scores.json API
app.get('/scores.json', function(request, response) {
	player = request.query.username;
//	var index;
  	// enable Cross-origun resource sharing
  	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");

  	if(player === undefined) {
  		response.send("[]");
  	}
  	else {
  		db.collection('scores', function(error, collection){
  			collection.find({username: player}).sort({score: -1}).toArray(function(err, cursor){
        		response.send(JSON.stringify(cursor));
//				index = JSON.stringify(cursor);  why cannot do this?
      		});

  		});
	}
//	response.set('Content-Type', 'text/json');
//  response.send(player+": "+index);

});

app.listen(process.env.PORT || 3000);